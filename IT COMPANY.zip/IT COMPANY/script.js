let calcScrollValue = () => {
let scrollProgress = document.getElementById
("progress");
let progressValue = document.getElementById
("progress-value");
let pos = document.documentElement.scrollTop;
let calcHeight = 
document.documentElement.scrollHeight - 
document.documentElement.clientHeight;
let scrollValue = Math.round((pos * 100) / calcHeight)
console.log(scrollValue);
};

window.onscroll = calcScrollValue;
window.onload = calcScrollValue;


var navLinks = document.getElementById("navLinks");

function showMenu(){
  navLinks.style.right = "0";
}
function hideMenu(){
  navLinks.style.right = "-200px";
}

AOS.init();